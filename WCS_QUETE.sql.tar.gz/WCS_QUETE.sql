-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Dim 24 Septembre 2017 à 13:19
-- Version du serveur :  5.7.19-0ubuntu0.16.04.1
-- Version de PHP :  7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `WCS_QUETE`
--

-- --------------------------------------------------------

--
-- Structure de la table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `booking_time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `booking`
--

INSERT INTO `booking` (`booking_id`, `users_id`, `class_id`, `booking_date`, `booking_time`) VALUES
(1, 1, 1, '2017-09-25', '9h30-12h'),
(2, 2, 1, '2017-09-25', '14h-16h'),
(3, 3, 1, '2017-09-25', '16h-18h'),
(4, 4, 3, '2017-09-25', '9h-12h'),
(5, 5, 5, '2017-09-25', '10h-12h'),
(6, 6, 5, '2017-09-25', '14h-16h'),
(7, 7, 6, '2017-09-25', '9h-10h'),
(8, 8, 6, '2017-09-25', '10h-12h'),
(9, 9, 6, '2017-09-25', '14h-16h'),
(10, 10, 6, '2017-09-25', '16h-17h');

-- --------------------------------------------------------

--
-- Structure de la table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `class`
--

INSERT INTO `class` (`class_id`, `class_name`) VALUES
(1, 'Salle de dojo'),
(2, 'Salle de reunion'),
(3, 'Salle de repos'),
(4, 'cuisine'),
(5, 'Bureau'),
(6, 'OpenSpace');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `users_id` int(11) NOT NULL,
  `users_lastname` varchar(40) CHARACTER SET utf8 NOT NULL,
  `users_firstname` varchar(40) CHARACTER SET utf8 NOT NULL,
  `trainers` tinyint(1) NOT NULL,
  `langagae` varchar(40) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`users_id`, `users_lastname`, `users_firstname`, `trainers`, `langagae`) VALUES
(1, 'mouse', 'mickey', 0, 'php'),
(2, 'duck', 'donald', 1, 'php'),
(3, 'lourson', 'winnie', 0, 'js'),
(4, 'cricket', 'jimmy', 0, 'php'),
(5, 'neige', 'blanche', 0, 'js'),
(6, 'bunny', 'bugs', 1, 'php'),
(7, 'volant', 'tapis', 1, 'php'),
(8, 'lelion', 'simba', 0, 'js'),
(9, 'google', 'google', 0, 'js'),
(10, 'laurie', 'laurie', 0, 'js');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`),
  ADD UNIQUE KEY `trainers_id` (`users_id`),
  ADD UNIQUE KEY `booking_id` (`booking_id`);

--
-- Index pour la table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `users_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`users_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
